export class PrintDto {
  data: any;
  dataPrivacyTexts: any;
}
