export const SERVICE_ID = 'FDPG_PDF_SERVICE';
export const SERVICE_NAME = 'FDPG PDF Service';
export const SERVICE_ID_SHORT = 'fdpg-pdf';
export const API_PREFIX = '/api';
export const SWAGGER_PATH = `${API_PREFIX}/swagger-ui`;
